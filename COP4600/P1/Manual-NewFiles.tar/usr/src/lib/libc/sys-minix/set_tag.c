#include <lib.h>
#include <unistd.h>

int set_tag(int PID, int newValue)
{
	message m;
	m.m1_i1 = PID;
	m.m1_i2 = newValue;
	
	return _syscall(PM_PROC_NR, SETTAG, &m);
}