#include <stdio.h>
#include "pm.h"
#include "mproc.h"

int do_gettag()
{
	int PID = m_in.m1_i1;
	int tag = -1;
	
	struct mproc *target_process = find_proc(PID);
	
	if( target_process == NULL ) return tag;
	else if( mp->mp_pid != PID && mp->mp_effuid != 0 ) return tag;
	else
	{
		tag = target_process->mp_tag;
		return tag;
	}
}