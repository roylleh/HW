#include <stdio.h>
#include "pm.h"
#include "mproc.h"

int do_settag()
{
	int PID = m_in.m1_i1;
	int newValue = m_in.m1_i2;
	int tag = -1;
	
	struct mproc *target_process = find_proc(PID);
	
	if( newValue < 0 ) return tag;
	else if( target_process == NULL ) return tag;
	else if( mp->mp_effuid != 0 ) return tag;
	else
	{
		target_process->mp_tag = newValue;
		tag = target_process->mp_tag;
		
		return tag;
	}
}