#include <errno.h>
#include <lib.h>
#include <stdio.h>
#include <unistd.h>

int get_class(FILE* fd)
{
	int fn = -1;
	if(fd == NULL)
	{
		errno = ENOENT;
		return fn;
	}
	fn = fileno(fd);
	
	message m;
	m.m1_i1 = fn;
	
	return _syscall(VFS_PROC_NR, GETCLASS, &m);
}