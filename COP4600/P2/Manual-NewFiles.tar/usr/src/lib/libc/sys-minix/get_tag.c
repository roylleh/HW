#include <lib.h>
#include <unistd.h>

int get_tag(int PID)
{
	message m;
	m.m1_i1 = PID;
	
	return _syscall(PM_PROC_NR, GETTAG, &m);
}