#include <errno.h>
#include <lib.h>
#include <stdio.h>
#include <unistd.h>

int set_class(FILE* fd, int newValue)
{
	int fn = -1;
	if(fd == NULL)
	{
		errno = ENOENT;
		return fn;
	}
	else if(newValue < 0)
	{
		errno = EINVAL;
		return fn;
	}
	fn = fileno(fd);
	
	message m;
	m.m1_i1 = fn;
	m.m1_i2 = newValue;
	
	return _syscall(VFS_PROC_NR, SETCLASS, &m);
}