#include <errno.h>
#include "pm.h"
#include "mproc.h"

int do_settag()
{
	int PID = m_in.m1_i1;
	int newValue = m_in.m1_i2;
	int tag = -1;
	
	struct mproc *target_process = find_proc(PID);
	
	if( newValue < 0 )
	{
		errno = EINVAL;
		return tag;
	}
	else if( target_process == NULL )
	{
		errno = ESRCH;
		return tag;
	}
	else if( mp->mp_effuid != 0 )
	{
		errno = EACCES;
		return tag;
	}
	
	target_process->mp_tag = newValue;
	tag = target_process->mp_tag;
	
	return tag;
}