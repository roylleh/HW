#include <errno.h>
#include "fs.h"
#include "file.h"
#include "fproc.h"
#include "vnode.h"

int do_getclass()
{
	int fd = m_in.m1_i1;
	int class = -1;
	
	struct filp *target_file = get_filp( fd, VNODE_READ );
	
	if( target_file == NULL )
	{
		errno = ENOENT;
		unlock_filp( target_file );
		return class;
	}
	
	class = target_file->filp_vno->v_class;
	unlock_filp( target_file );
	
	return class;
}