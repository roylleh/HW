#include <errno.h>
#include "fs.h"
#include "file.h"
#include "fproc.h"
#include "vnode.h"

int do_setclass()
{
	int fd = m_in.m1_i1;
	int newValue = m_in.m1_i2;
	int class = -1;
	
	struct filp *target_file = get_filp( fd, VNODE_WRITE );
	
	if( target_file == NULL )
	{
		errno = ENOENT;
		unlock_filp( target_file );
		return class;
	}
	else if(fp->fp_effuid != 0 )
	{
		errno = EACCES;
		unlock_filp( target_file );
		return class;
	}
	
	target_file->filp_vno->v_class = newValue;
	class = target_file->filp_vno->v_class;
	unlock_filp( target_file );
	
	return class;
}